Read the ppt file. Everything is described there.
